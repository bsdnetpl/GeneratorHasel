﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeneratorHasel
{
    public class Generator
    {
        private string[] alphabet = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "R", "S", "T", "U", "W", "Y", "Z" };
        private string[] alphabetLitle = { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "r", "s", "t", "u", "w", "y", "z" };
        private string[] alphabetNumeric= { "1", "2", "3", "4", "5", "6", "7", "8", "9", "0" };
        private string[] alphabetSpecial = { "!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "-", "=", "+" };
        private string result;
        Random rnd = new Random();
        public string GeneratePassword(int LongPassword)
        {
            var Password = new List<string>();
            for (int i = 0; i < LongPassword; i++)
            {
                int RandomTable = rnd.Next(1, 5);
                if (RandomTable == 1)
                {
                    int row = rnd.Next(0, alphabet.Count());
                    Password.Add(alphabet[row]);
                }
                if (RandomTable == 2)
                {
                    int row = rnd.Next(0, alphabetLitle.Count());
                    Password.Add(alphabetLitle[row]);
                }
                if (RandomTable == 3)
                {
                    int row = rnd.Next(0, alphabetNumeric.Count());
                    Password.Add(alphabetNumeric[row]);
                }
                if (RandomTable == 4)
                {
                    int row = rnd.Next(0, alphabetSpecial.Count());
                    Password.Add(alphabetSpecial[row]);
                }
            }
            result = string.Join("", Password);
            return this.result;
        }

     public void SaveToFileAsync()
        {
            //this.result = this.result + "    " + DateTime.Today;
             File.WriteAllText("Password.txt",this.result);
        }
    }
} 
